<template>
    <ul v-if="propositos.length > 0">
        <li v-for="(proposito, index) in propositos" :key="index" :class="[proposito.hecho == true ? 'verdeDerecha' : 'rojoSquare']" @dblclick="eliminarElementoLista(index)">
            <input type="checkbox" v-model="proposito.hecho">
            <span v-if="proposito.hecho===true"><del>{{proposito.texto}}</del></span>
            <span v-else>{{proposito.texto}}</span>        
        </li>
    </ul>
    <p v-else> La lista de propósitos está vacía.</p>
</template>

<script>
export default {
    name: "listaPropositos",
    props: ['propositos'],

    methods: {
        eliminarElementoLista(index){
            this.propositos.splice(index, 1);
        }
    },
}
</script>

<style>

.verdeDerecha{
    color: green;
    text-align: right;
    font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

.rojoSquare{
    color: red;
    list-style: square;
    font-family: fantasy;
}

</style>