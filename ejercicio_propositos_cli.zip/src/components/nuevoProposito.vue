<template>
    <div>
        <input  @keyup.enter="aniadirNuevoProposito" type="text" v-model="valorInput">
        <button @click="aniadirNuevoProposito">Añadir nuevo propósito</button>
    </div>
</template>

<script>
export default {
    name: "nuevoProposito",
    props: ['propositos'],

    data() {
        return {
            valorInput: ""
        };
    },

    methods: {
        aniadirNuevoProposito(){
            if (this.valorInput!=""){
                let nuevoProposito = {texto: this.valorInput, hecho: false}
                this.propositos.push(nuevoProposito);
                this.valorInput = "";
            }
        }
    },
}
</script>