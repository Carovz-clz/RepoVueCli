<template>
    <div >
        <h1 :class="asignarClaseTitulo"> Propósitos de año nuevo</h1>

       <listaPropositos :propositos="propositos"></listaPropositos>

       <nuevoProposito :propositos="propositos"></nuevoProposito>

       <br><br>
       <button @click="borrarLista">Borrar lista</button>
    </div>
</template>

<script>
    import listaPropositos from "./components/listaPropositos.vue";
    import nuevoProposito from "./components/nuevoProposito.vue";
    
    export default {
        name: "App",
        components: {
            listaPropositos, nuevoProposito
        },

        data() {
            return {
                nuevoProp:"",
                propositos:[
                    {texto:"Hacer deporte", hecho:false},
                    {texto:"Comer mas sano", hecho:true},
                    {texto:"Viajar mas", hecho:true}
                ],
                valorInput: ""
            };
        },

        methods: {
            borrarLista(){
                let confirmacion = window.confirm("¿Está seguro que quiere borrar toda la lista de propósitos?");

                if(confirmacion){
                    this.propositos = [];
                }
            }
        },

        computed : {
            asignarClaseTitulo() {
                let propCumplidos = 0;

                this.propositos.forEach(element => {
                    if(element.hecho == true){
                        propCumplidos++;
                    }
                });

                if((propCumplidos > 3) && (propCumplidos <= 5)){
                    return 'amarilloFondoNegroCentro';
                }else if (propCumplidos > 5){
                    return 'rosaFondoVerdeCentro';
                }else{
                    return '';
                }
            }
        }
    }
</script>

<style>

.amarilloFondoNegroCentro{
    color: yellow;
    background-color: black;
    text-align: center;
}

.rosaFondoVerdeCentro{
    color: pink;
    background-color: green;
    text-align: center;
}

</style>