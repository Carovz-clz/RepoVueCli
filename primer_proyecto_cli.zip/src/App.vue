<template>
  <div id="app">
    <h1>{{ mensaje }}</h1>
    <hr />
    <span> Libros disponibles:</span>
    <listaLibros :libros="libros"></listaLibros>
    <hr />
    <piePagina :tel-user="telefono" dir="C/Arriba 25" />
  </div>
</template>

<script>
  import piePagina from "./components/PiePagina.vue";
  import listaLibros from "./components/ListaLibros.vue";

  export default {
    name: "App",
    components: {
      piePagina, listaLibros
    },
    data() {
      return {
        mensaje: "Librería Mi Mundo de Papel",
        telefono: 923451111,
        libros: [
          { titulo: "La villa de las telas" },
          { titulo: "La isla de las tormentas" },
          { titulo: "Dime quien soy" },
        ],
      };
    },
    methods: {
      mostrarAlerta() {
        alert("Número de libros almacenados:" + this.libros.length);
      },
    },
  };
</script>

<style>
  h1, h2, h3, h4, h5 {
    text-align: center;
  }

  footer {
    position: absolute;
    bottom: 0;
    background-color: aquamarine;
    width: 100%;
  }
</style>