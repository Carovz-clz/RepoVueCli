<template>
  <footer>
    <h3>Sitio Web de Sonia Gutiérrez</h3>
    <h4>{{ mensaje }} - {{ telUser }}</h4>
    <h5>{{ dir }}</h5>
  </footer>
</template>

<script>
    export default {
      name: "piePagina",
      props: ["telUser", "dir"],
      data() {
        return {
        mensaje: "Librería especializada",
        };
      }
    };
</script>